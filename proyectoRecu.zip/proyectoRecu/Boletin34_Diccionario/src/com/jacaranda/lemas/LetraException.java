package com.jacaranda.lemas;

public class LetraException extends Exception {

	public LetraException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LetraException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public LetraException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public LetraException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public LetraException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
