import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.jacaranda.lemas.LemaException;
import com.jacaranda.lemas.LetraException;
import com.jacaranda.lemas.Palabra;

public class testPalabra {

	/*
	 * Comprobacion de que busca la palabra
	 */
	@Test
	public void testaddPalabra() throws LemaException {
		Palabra target = new Palabra("HOLA");
		String expected = "HOLA";
		assertEquals("No existe la palabra", target.getNombre(), expected);

	}

}

	/*
	 * Comprobacion de que borra la palabra /
	 */
	@Test
	public void testBorrarPalabra() throws LemaException {
		Palabra target = new Palabra("HOLA");
		String expected = "HOLA";
		assertEquals("No existe la palabra", target.getNombre(), expected);

	}

	/*
	 * Comprobacion de que devuelve una lista de palabras de una cadena
	 */
	@Test
	public void testListaPalabra() throws LetraException, LemaException {
		Palabra target = new Palabra("HOLA");
		String expected = "HOLA";
		assertEquals("No existe la palabra", target.getNombre(), expected);

	}

	/*
	 */
	@Test
	public void testBuscarPalabra() throws LemaException {
		Palabra target = new Palabra("HOLA");
		String expected = "HOLA";

	}
	

	/*
	 * Comprueba que existe la palabra
	 */
	@Test
	public void testExistePalabra() throws LemaException {
		Palabra target = new Palabra("HOLA");
		String expected = "HOLA";
		assertEquals("No existe la palabra", target.getNombre(), expected);

	}


}
